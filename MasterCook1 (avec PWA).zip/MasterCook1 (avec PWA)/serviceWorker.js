const CacheName = "cache-v1";
const assets = [
"/",
"index.html",
"affichage.js",
"constructeur.js",
"effacer.js",
"initialisation.js",
"mastermind.js",
"placer.js",
"recommencer.js",
"soluce.js",
"uneboule.js",
"verifier.js"
];

//Ajout de fichiers dans le cache
self.addEventListener("install", (e) => {
	e.waitUntil(
		caches
    .open(CacheName)
    .then((cache) => {
			cache.addAll(assets)
		})
	);
});

self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches
    .match(event.request).then(function(response) {
        if (response) {
          return response;
        }

        // Nous clonons la requête
        // Une requete est un flux et est à consommation unique : il est donc nécessaire de copier la requete pour pouvoir l'utiliser et la servir
        var fetchRequest = event.request.clone();

        return fetch(fetchRequest).then(function(response) {
            if (!response || response.status !== 200 || response.type !== "basic") {
              return response;
            }

            // IMPORTANT: Même constat qu'au dessus, mais pour la mettre en cache
            var responseToCache = response.clone();

            caches.open(CacheName).then(function (cache) {
                cache.put(event.request, responseToCache);
              });

            return response;
          });
      })
  );
});

 