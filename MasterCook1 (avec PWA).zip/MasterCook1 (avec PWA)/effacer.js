	//fonction d'effacement d'une ligne 			
	function effacer() {
		for (colonne=1;colonne <= this.nbcolonnes;colonne++) {
			//r�initialisation des images de la ligne
			img_en_cour='i' + ligne + colonne;
			document[img_en_cour].src='vide.png';
		};
		//remise de la position de colonne a 1
		colonne=1;
	};