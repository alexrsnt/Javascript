//Ce mastermind a �t� r�aliser par David De Groote (dadg@freesurf.ch), apprenti informaticien � l'EHMP
	//D�claration de l'objet uneboule qui ets une boule du mastermind
	function UneBoule(couleur, etat) {
		this.couleur = couleur;
		this.etat = etat;
	};