//Ce mastermind a �t� r�aliser par David De Groote (dadg@freesurf.ch), apprenti informaticien � l'EHMP
	//function d'insertion des couleurs dans la soluce !
	function soluce() {
		for (i=1;i<=this.nbcolonnes;i++) {
			img_en_cour='s' + i;
			adresse= + this.solution[i].couleur + '.png';
			//change l'adresse de l'image
			document[img_en_cour].src=adresse;	
		};
	};